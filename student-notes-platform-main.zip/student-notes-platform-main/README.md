# Student Notes Platform

A full-stack web application where students can upload, read, download, search, filter, rate, and manage academic notes.

## Features

- User registration and login
- JWT-based authentication
- Password hashing using bcrypt
- Protected note upload
- PDF-only file uploads
- 5 MB upload limit
- Browse uploaded notes
- Search notes by title
- Filter notes by subject and semester
- Read PDFs directly in the browser
- Download PDFs
- Rate notes from 1–5 stars
- Update an existing rating
- Display average note ratings
- Users can delete only their own uploaded notes
- Responsive frontend
- Logout functionality

## Tech Stack

### Frontend

- React
- React Router
- JavaScript
- HTML
- CSS
- Vite

### Backend

- Node.js
- Express.js
- MongoDB
- Mongoose
- JWT
- bcryptjs
- Multer

## Project Structure

```text
student-notes-platform/
│
├── backend/
│   ├── middleware/
│   │   └── authMiddleware.js
│   │
│   ├── models/
│   │   ├── Note.js
│   │   └── User.js
│   │
│   ├── routes/
│   │   ├── auth.js
│   │   └── notes.js
│   │
│   ├── uploads/
│   ├── .env
│   └── ...
│
├── frontend/
│   ├── src/
│   │   ├── Components/
│   │   ├── pages/
│   │   ├── App.jsx
│   │   └── index.css
│   └── ...
│
├── .gitignore
└── README.md
```

> `.env`, `node_modules`, uploaded files, and build output should not be committed to GitHub.

## How the Application Works

### 1. User Registration

A user enters their name, email, and password.

The frontend sends the information to the Express backend.

The backend:

1. Validates the input.
2. Normalizes the email.
3. Checks whether the email already exists.
4. Hashes the password using bcrypt.
5. Stores the user in MongoDB.

The plain-text password is never stored.

### 2. User Login

The user enters their email and password.

The backend:

1. Finds the user by email.
2. Compares the entered password with the stored bcrypt hash.
3. Creates a JWT containing the user's ID.
4. Sends the token to the frontend.

The frontend stores the token in `localStorage`.

### 3. Authentication

Protected requests send the JWT using the `Authorization` header:

```text
Authorization: Bearer <token>
```

The authentication middleware:

1. Reads the token.
2. Verifies the JWT.
3. Extracts the user's ID.
4. Stores it in `req.userId`.
5. Allows the request to continue.

This protects operations such as uploading, rating, and deleting notes.

### 4. Uploading Notes

A logged-in user selects:

- Note title
- Subject
- Semester
- PDF file

The frontend sends the data using `FormData`.

Multer handles the uploaded file on the Express server.

The backend validates:

- Required fields
- PDF file type
- Maximum file size
- Valid semester

The backend also gets the logged-in user's identity from the JWT instead of trusting the frontend.

The note is then stored in MongoDB with information such as:

- Title
- Subject
- Semester
- Author
- File path
- User who uploaded it
- Ratings

### 5. Reading Notes

The frontend requests the notes from the backend.

The backend retrieves the notes from MongoDB and calculates the average rating for each note.

The frontend displays the notes as cards.

Users can:

- Search notes
- Filter by semester
- Filter by subject
- Read PDFs
- Download PDFs
- Rate notes

### 6. Rating System

Each note contains ratings associated with users.

A rating contains:

```text
user
value
```

When a user rates a note:

- If they have never rated it, a new rating is added.
- If they already rated it, their existing rating is updated.

This prevents one user from creating multiple ratings for the same note.

The backend calculates the average rating from all ratings.

### 7. Delete Authorization

Users cannot delete arbitrary notes.

When deleting a note, the backend compares:

```text
note.uploadedBy
```

with:

```text
req.userId
```

Only the user who originally uploaded the note can delete it.

This authorization check is performed on the backend rather than relying on the frontend.

## API Overview

### Authentication

```text
POST /api/auth/register
POST /api/auth/login
```

### Notes

```text
POST   /api/notes/upload
GET    /api/notes
GET    /api/notes/:id/download
DELETE /api/notes/:id
PATCH  /api/notes/:id/rating
GET    /api/notes/:id/my-rating
```

## Environment Variables

Create a `.env` file inside the backend directory.

Example:

```env
MONGO_URI=your_mongodb_connection_string
JWT_SECRET=your_jwt_secret
```

Do not commit the `.env` file to GitHub.

## Running the Project Locally

### Backend

Navigate to the backend directory:

```bash
cd backend
```

Install dependencies:

```bash
npm install
```

Create the `.env` file and add your MongoDB connection string and JWT secret.

Start the backend:

```bash
npm run dev
```

or use the start command configured in your `package.json`.

The backend runs on:

```text
http://localhost:3020
```

### Frontend

Open another terminal:

```bash
cd frontend
```

Install dependencies:

```bash
npm install
```

Start the development server:

```bash
npm run dev
```

The frontend runs on the Vite development server, usually:

```text
http://localhost:5173
```

## Security Considerations

- Passwords are hashed using bcrypt.
- Authentication uses JWT.
- Protected operations require authentication.
- Users can delete only their own notes.
- The JWT secret is stored in an environment variable.
- `.env` is excluded from Git.
- Uploaded files are excluded from Git.
- PDF uploads are restricted to 5 MB.
- Only PDF files are accepted.

## Future Improvements

Possible future improvements include:

- Comments on notes
- User profiles
- Pagination
- Better subject management
- Admin moderation
- Cloud file storage
- Deployment
- More advanced search
- Notifications
- Bookmarking/favorites

## What I Learned

This project helped me understand how a full-stack application connects the frontend, backend, database, authentication, file handling, and REST APIs.

Key concepts practiced include:

- React components and state
- React Router
- REST APIs
- Express middleware
- JWT authentication
- Password hashing
- MongoDB and Mongoose
- CRUD operations
- File uploads with Multer
- Authorization
- API error handling
- Frontend/backend integration
