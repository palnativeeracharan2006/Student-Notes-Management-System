import dotenv from "dotenv";
import mongoose from "mongoose";
import express from "express";
import noteRoutes from "./routes/noteRoutes.js";
import authRoutes from "./routes/authRoutes.js";
import cors from "cors";

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());

app.use("/uploads", express.static("uploads"));
app.use("/api/notes", noteRoutes);
app.use("/api/auth", authRoutes);

mongoose
  .connect(process.env.MONGO_URI)
  .then(function () {
    console.log("MongoDB connected!");
  })
  .catch(function (error) {
    console.log("MongoDB connection failed");
    console.log(error);
  });

const PORT = 3020;

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
