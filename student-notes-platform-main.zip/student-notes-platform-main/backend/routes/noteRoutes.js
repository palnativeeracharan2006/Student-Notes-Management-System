import express from "express";
import { Note } from "../models/Note.js";
import { User } from "../models/User.js";
import multer from "multer";
import { authMiddleware } from "../middleware/authMiddleware.js";

// creates a router — a smaller group of related endpoints.
const router = express.Router();

const upload = multer({
  dest: "uploads/",
  limits: {
    fileSize: 5 * 1024 * 1024,
  },
  fileFilter: function (req, file, cb) {
    if (file.mimetype === "application/pdf") {
      cb(null, true);
    } else {
      cb(new Error("Only PDF files are allowed"));
    }
  },
});
//i am execting 1 file and name must be file
router.post("/upload", authMiddleware, function (req, res) {
  upload.single("file")(req, res, async function (error) {
    try {
      if (error) {
        return res.status(400).json({
          message: error.message,
        });
      }
      if (!req.file) {
        return res.status(400).json({ message: "PDF file is required" });
      }
      const user = await User.findById(req.userId);

      if (!user) {
        return res.status(401).json({
          message: "User not found",
        });
      }
      const title = req.body.title.trim();
      const subject = req.body.subject.trim();

      if (!title || !subject || !req.body.semester) {
        return res.status(400).json({
          message: "All fields are required",
        });
      }
      const semester = Number(req.body.semester);

      if (!Number.isInteger(semester) || semester < 1 || semester > 8) {
        return res.status(400).json({
          message: "Semester must be between 1 and 8",
        });
      }
      const note = new Note({
        title: title,
        subject: subject,
        semester: semester,
        author: user.name,
        filePath: req.file.path,
        uploadedBy: req.userId,
      });

      await note.save();

      res.status(201).json({
        message: "Note uploaded successfully",
        note: note,
      });
    } catch (error) {
      console.log(error);

      res.status(500).json({
        message: "Failed to upload note",
      });
    }
  });
});

router.get("/:id/download", async function (req, res) {
  try {
    const note = await Note.findById(req.params.id);

    if (!note) {
      return res.status(404).json({
        message: "Note not found",
      });
    }

    res.download(note.filePath, function (error) {
      if (error) {
        console.log(error);

        if (!res.headersSent) {
          res.status(404).json({
            message: "File not found",
          });
        }
      }
    });
  } catch (error) {
    console.log(error);

    res.status(500).json({
      message: "Failed to download note",
    });
  }
});

router.delete("/:id", authMiddleware, async (req, res) => {
  try {
    const note = await Note.findById(req.params.id);
    if (!note) {
      return res.status(404).json({
        message: "Note not found",
      });
    }
    if (!note.uploadedBy || note.uploadedBy.toString() !== req.userId) {
      return res.status(403).json({
        message: "You can only delete your own notes",
      });
    }
    await Note.findByIdAndDelete(req.params.id);
    res.status(200).json({
      message: "Note deleted successfully!",
    });
  } catch (error) {
    console.log(error);

    res.status(500).json({
      message: "Failed to delete note",
    });
  }
});

router.patch("/:id/rating", authMiddleware, async function (req, res) {
  try {
    const rating = Number(req.body.rating);

    if (!Number.isInteger(rating) || rating < 1 || rating > 5) {
      return res.status(400).json({
        message: "Rating must be an integer between 1 and 5",
      });
    }

    const note = await Note.findById(req.params.id);

    if (!note) {
      return res.status(404).json({
        message: "Note not found",
      });
    }

    const existingRating = note.ratings.find(function (item) {
      return item.user.toString() === req.userId;
    });

    if (existingRating) {
      existingRating.value = rating;
    } else {
      note.ratings.push({
        user: req.userId,
        value: rating,
      });
    }

    await note.save();

    const total = note.ratings.reduce(function (sum, item) {
      return sum + item.value;
    }, 0);

    const averageRating =
      note.ratings.length > 0 ? total / note.ratings.length : 0;

    res.status(200).json({
      message: "Rating saved successfully",
      averageRating,
    });
  } catch (error) {
    console.log(error);

    res.status(500).json({
      message: "Failed to save rating",
    });
  }
});

router.get("/:id/my-rating", authMiddleware, async function (req, res) {
  try {
    const note = await Note.findById(req.params.id);

    if (!note) {
      return res.status(404).json({
        message: "Note not found",
      });
    }

    const existingRating = note.ratings.find(function (item) {
      return item.user.toString() === req.userId;
    });

    res.status(200).json({
      rating: existingRating ? existingRating.value : null,
    });
  } catch (error) {
    res.status(500).json({
      message: "Failed to fetch rating",
    });
  }
});
router.get("/", async function (req, res) {
  try {
    const notes = await Note.find();

    const notesWithAverage = notes.map(function (note) {
      const total = note.ratings.reduce(function (sum, item) {
        return sum + item.value;
      }, 0);

      const averageRating =
        note.ratings.length > 0 ? total / note.ratings.length : 0;

      return {
        ...note.toObject(),
        averageRating,
      };
    });

    res.status(200).json(notesWithAverage);
  } catch (error) {
    res.status(500).json({
      message: "Failed to fetch notes",
    });
  }
});

export default router;
