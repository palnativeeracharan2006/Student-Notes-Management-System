import { Link } from "react-router-dom";

export function Navbar() {
  const isLoggedIn = Boolean(localStorage.getItem("token"));

  function handleLogout() {
    localStorage.removeItem("token");
    window.location.href = "/login";
  }

  return (
    <nav className="navbar">
      <h2>Student Notes</h2>

      <div className="nav-links">
        <Link to="/read">Read</Link>
        <Link to="/upload">Upload</Link>

        {isLoggedIn ? (
          <button onClick={handleLogout}>Logout</button>
        ) : (
          <>
            <Link to="/login">Sign In</Link>
            <Link to="/signUp">Sign Up</Link>
          </>
        )}
      </div>
    </nav>
  );
}
