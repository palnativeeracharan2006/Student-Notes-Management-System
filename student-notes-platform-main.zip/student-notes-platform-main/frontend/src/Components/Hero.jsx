import { Link } from "react-router-dom";

export function Hero() {
  return (
    <section className="hero">
      <h1>Your Notes, Your Knowledge</h1>
      <p>Find, read and share notes with fellow students.</p>

      <div className="hero-buttons">
        <Link to="/read">
          <button>Read Notes</button>
        </Link>

        <Link to="/upload">
          <button>Upload Notes</button>
        </Link>
      </div>
    </section>
  );
}
