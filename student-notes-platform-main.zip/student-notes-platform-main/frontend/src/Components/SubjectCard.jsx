import { Link } from "react-router-dom";
export function SubjectCard({ name, semester }) {
  return (
    <div className="subject-card">
      <h2> {name} </h2>
      <p> Semester {semester} </p>
      <Link to={`/read?subject=${encodeURIComponent(name)}`}>
        View Notes
      </Link>{" "}
    </div>
  );
}
