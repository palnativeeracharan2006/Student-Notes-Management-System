import { useEffect, useState } from "react";
export function NoteCard({
  title,
  author,
  averageRating,
  subject,
  filePath,
  id,
  onDelete,
}) {
  const [currentRating, setCurrentRating] = useState("");
  const [currentAverage, setCurrentAverage] = useState(averageRating);
  useEffect(
    function () {
      async function fetchMyRating() {
        const token = localStorage.getItem("token");

        if (!token) {
          return;
        }

        const response = await fetch(
          `http://localhost:3020/api/notes/${id}/my-rating`,
          {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          },
        );

        if (!response.ok) {
          return;
        }

        const data = await response.json();
        setCurrentRating(data.rating || "");
      }

      fetchMyRating();
    },
    [id],
  );
  const [ratingLoading, setRatingLoading] = useState(false);
  const [deleting, setDeleting] = useState(false);
  return (
    <div className="note-card">
      <p className="note-subject">{subject}</p>

      <h2>{title}</h2>

      <p className="note-author">Uploaded By {author}</p>

      <p className="note-rating">⭐ {currentAverage.toFixed(1)} average</p>

      <label className="rating-label">Your rating:</label>

      <select
        className="rating-select"
        value={currentRating || ""}
        disabled={ratingLoading}
        onChange={async function (e) {
          const token = localStorage.getItem("token");

          if (!token) {
            alert("Please login to rate notes");
            return;
          }

          const newRating = Number(e.target.value);
          setRatingLoading(true);
          setCurrentRating(newRating);

          const response = await fetch(
            `http://localhost:3020/api/notes/${id}/rating`,
            {
              method: "PATCH",
              headers: {
                "Content-Type": "application/json",
                Authorization: `Bearer ${localStorage.getItem("token")}`,
              },
              body: JSON.stringify({
                rating: newRating,
              }),
            },
          );

          if (!response.ok) {
            setRatingLoading(false);
            alert("Failed to save rating");
            return;
          }

          const data = await response.json();
          setCurrentAverage(data.averageRating);
          setRatingLoading(false);
        }}
      >
        <option value="">Rate</option>
        <option value="1">1 ⭐</option>
        <option value="2">2 ⭐</option>
        <option value="3">3 ⭐</option>
        <option value="4">4 ⭐</option>
        <option value="5">5 ⭐</option>
      </select>

      <div className="note-actions">
        {filePath && (
          <>
            <a
              href={`http://localhost:3020/${filePath.replaceAll("\\", "/")}`}
              target="_blank"
              rel="noreferrer"
            >
              <button>Read</button>
            </a>

            <a href={`http://localhost:3020/api/notes/${id}/download`}>
              <button>Download</button>
            </a>
          </>
        )}

        <button
          onClick={async function () {
            if (window.confirm("Are you sure you want to delete this note?")) {
              setDeleting(true);

              const deleted = await onDelete(id);

              if (!deleted) {
                setDeleting(false);
              }
            }
          }}
        >
          {deleting ? "Deleting..." : "Delete"}
        </button>
      </div>
    </div>
  );
}
