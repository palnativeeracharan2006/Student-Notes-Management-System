import { useState } from "react";
import { Navbar } from "../Components/Navbar";
import { useNavigate } from "react-router-dom";
export function UploadNotes() {
  const [noteName, setNoteName] = useState("");
  const [subject, setSubject] = useState("");
  const [semester, setSemester] = useState("");
  const [file, setFile] = useState(null);
  const [uploading, setUploading] = useState(false);
  const navigate = useNavigate();

  async function handleSubmit(e) {
    e.preventDefault();
    const token = localStorage.getItem("token");

    if (!token) {
      alert("Please login to upload notes");
      return;
    }
    if (!noteName || !subject || !semester || !file) {
      alert("Please fill all fields and select a PDF");
      return;
    }
    setUploading(true);
    const formData = new FormData();

    formData.append("file", file);
    formData.append("title", noteName);
    formData.append("subject", subject);
    formData.append("semester", Number(semester));

    const response = await fetch("http://localhost:3020/api/notes/upload", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${token}`,
      },
      body: formData,
    });

    const data = await response.json();

    if (!response.ok) {
      alert(data.message);
      setUploading(false);
      return;
    }

    setUploading(false);
    navigate("/read");
  }

  return (
    <div>
      <Navbar />

      <main className="upload-page">
        <div className="upload-card">
          <h1>Upload Notes</h1>

          <form onSubmit={handleSubmit} className="upload-form">
            <label>Note Name</label>
            <input
              type="text"
              placeholder="Enter note name"
              value={noteName}
              onChange={(e) => setNoteName(e.target.value)}
            />

            <label>Subject</label>
            <select
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
            >
              <option value="">Select Subject</option>
              <option value="Database Management Systems">
                Database Management Systems
              </option>
              <option value="Operating Systems">Operating Systems</option>
              <option value="Computer Networks">Computer Networks</option>
              <option value="Object Oriented Programming">
                Object Oriented Programming
              </option>
            </select>

            <label>Semester</label>
            <select
              value={semester}
              onChange={(e) => setSemester(e.target.value)}
            >
              <option value="">Select Semester</option>
              <option value="1">Semester 1</option>
              <option value="2">Semester 2</option>
              <option value="3">Semester 3</option>
              <option value="4">Semester 4</option>
              <option value="5">Semester 5</option>
              <option value="6">Semester 6</option>
              <option value="7">Semester 7</option>
              <option value="8">Semester 8</option>
            </select>

            <label>PDF</label>
            <input
              type="file"
              accept=".pdf"
              onChange={function (e) {
                const selectedFile = e.target.files[0];

                if (selectedFile && selectedFile.size > 5 * 1024 * 1024) {
                  alert("File must be less than 5 MB");
                  e.target.value = "";
                  return;
                }

                if (selectedFile && selectedFile.type !== "application/pdf") {
                  alert("Only PDF files are allowed");
                  e.target.value = "";
                  return;
                }

                setFile(selectedFile);
              }}
            />
            {file && <p>Selected: {file.name}</p>}
            <button type="submit" disabled={uploading}>
              {uploading ? "Uploading..." : "Upload Notes"}
            </button>
          </form>
        </div>
      </main>
    </div>
  );
}
