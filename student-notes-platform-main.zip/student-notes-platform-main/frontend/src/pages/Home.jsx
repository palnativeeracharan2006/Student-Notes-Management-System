import { SubjectCard } from "../Components/SubjectCard";
import { Navbar } from "../Components/Navbar";
import { Hero } from "../Components/Hero";
import "../App.css";

export function Home() {
  const subjects = [
    {
      id: 1,
      name: "Database Management Systems",
      semester: 4,
    },
    {
      id: 2,
      name: "Operating Systems",
      semester: 4,
    },
    {
      id: 3,
      name: "Computer Networks",
      semester: 4,
    },
    {
      id: 4,
      name: "Object Oriented Programming",
      semester: 4,
    },
  ];

  return (
    <div>
      <Navbar />

      <Hero />

      <main className="home-page">
        <section className="subjects-section">
          <h1>Student Notes Platform</h1>

          <p className="subjects-description">
            Find and explore notes shared by students.
          </p>

          <h2>Subjects</h2>

          <div className="subjects-container">
            {subjects.map(function (subject) {
              return (
                <SubjectCard
                  key={subject.id}
                  name={subject.name}
                  semester={subject.semester}
                />
              );
            })}
          </div>
        </section>
      </main>
    </div>
  );
}
