import { Navbar } from "../Components/Navbar";
import { NoteCard } from "../Components/NoteCard";
import { useSearchParams } from "react-router-dom";
import { useEffect, useState } from "react";

export function ReadNotes() {
  const [searchParams, setSearchParams] = useSearchParams();
  const semester = searchParams.get("semester");
  const subject = searchParams.get("subject");

  const [notes, setNotes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [search, setSearch] = useState("");

  useEffect(function () {
    fetch("http://localhost:3020/api/notes")
      .then(function (response) {
        return response.json();
      })
      .then(function (data) {
        setNotes(data);
        setLoading(false);
      })
      .catch(function () {
        setError("Failed to load notes");
        setLoading(false);
      });
  }, []);

  async function handleDelete(id) {
    const response = await fetch(`http://localhost:3020/api/notes/${id}`, {
      method: "DELETE",
      headers: {
        Authorization: `Bearer ${localStorage.getItem("token")}`,
      },
    });

    if (!response.ok) {
      const data = await response.json();
      alert(data.message);
      return false;
    }

    setNotes(function (oldNotes) {
      return oldNotes.filter(function (note) {
        return String(note._id) !== String(id);
      });
    });
  }

  const filteredNotes = notes.filter(function (note) {
    return (
      (!subject || note.subject === subject) &&
      (!semester || note.semester === Number(semester)) &&
      (!search || note.title.toLowerCase().includes(search.toLowerCase()))
    );
  });
  return (
    <div>
      <Navbar />

      <main className="read-page">
        <h1>Read Notes</h1>

        <p>Find Notes Uploaded by Students</p>
        <input
          type="text"
          placeholder="Search notes..."
          value={search}
          onChange={function (e) {
            setSearch(e.target.value);
          }}
        />
        <select
          value={semester || ""}
          onChange={function (e) {
            const value = e.target.value;

            if (value) {
              setSearchParams({ semester: value });
            } else {
              setSearchParams({});
            }
          }}
        >
          <option value="">All Semesters</option>
          <option value="1">Semester 1</option>
          <option value="2">Semester 2</option>
          <option value="3">Semester 3</option>
          <option value="4">Semester 4</option>
          <option value="5">Semester 5</option>
          <option value="6">Semester 6</option>
          <option value="7">Semester 7</option>
          <option value="8">Semester 8</option>
        </select>
        {loading && <p>Loading notes...</p>}
        {error && <p>{error}</p>}
        <div className="notes-container">
          {filteredNotes.length === 0 && <p>No notes found.</p>}
          {filteredNotes.map(function (note) {
            console.log(note);
            return (
              <NoteCard
                key={note._id}
                title={note.title}
                author={note.author}
                averageRating={note.averageRating}
                subject={note.subject}
                filePath={note.filePath}
                id={note._id}
                onDelete={handleDelete}
              />
            );
          })}
        </div>
      </main>
    </div>
  );
}

//main -> semantic element that represents main content of a page
