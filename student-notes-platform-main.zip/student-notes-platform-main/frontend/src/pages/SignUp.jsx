import { useState } from "react";
import { Link } from "react-router-dom";
import { useNavigate } from "react-router-dom";

export function SignUp() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const navigate = useNavigate();

  async function handleSubmit(e) {
    e.preventDefault();

    const response = await fetch("http://localhost:3020/api/auth/register", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        name,
        email,
        password,
      }),
    });

    const data = await response.json();

    if (!response.ok) {
      alert(data.message);
      return;
    }

    navigate("/login");
  }

  return (
    <div className="auth-page">
      <div className="auth-card">
        <h1>Register</h1>

        <form onSubmit={handleSubmit} className="auth-form">
          <input
            type="text"
            placeholder="Name"
            value={name}
            onChange={function (e) {
              setName(e.target.value);
            }}
          />

          <input
            type="email"
            placeholder="Email"
            value={email}
            onChange={function (e) {
              setEmail(e.target.value);
            }}
          />

          <input
            type="password"
            placeholder="Password"
            value={password}
            onChange={function (e) {
              setPassword(e.target.value);
            }}
          />

          <button type="submit">Register</button>
        </form>

        <p className="auth-switch">
          Already have an account? <Link to="/login">Login</Link>
        </p>
      </div>
    </div>
  );
}
